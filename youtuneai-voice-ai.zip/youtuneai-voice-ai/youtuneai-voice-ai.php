
<?php
/*
Plugin Name: YouTuneAI Voice AI Controller
Description: Adds voice-triggered GPT/AI automation to your site. Deploy, update, and command by voice or chat with CustomGPT.ai premium.
Version: 1.0.0
Author: Boss Man J + ChatGPT
*/

// 1. Inject CustomGPT.ai Chat Bubble + Voice UI + Hotword Listener in footer
add_action('wp_footer', function() {
    // CustomGPT.ai hardcoded keys
    $pid = '7933';
    $pkey = 'XYAM0qsx6lzKb4PPCJ1yx0BMrttKGKY56i1E6VtD60a4507f';
    ?>
    <!-- CustomGPT.ai Chat Bubble -->
    <script defer src="https://cdn.customgpt.ai/js/chat.js"></script>
    <script defer>
        window.onload = function() {
            if (window.CustomGPT) {
                CustomGPT.init({p_id: '<?php echo $pid; ?>', p_key: '<?php echo $pkey; ?>'});
            }
        };
    </script>
    <!-- YouTuneAI Voice Button & Command Handler -->
    <script>
    let recognizing = false;
    let recognition;
    function startVoiceGPT() {
        if (!('webkitSpeechRecognition' in window)) {
            alert('Voice recognition not supported');
            return;
        }
        recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = "en-US";
        recognition.onresult = function(event) {
            recognizing = false;
            let text = event.results[0][0].transcript.trim();
            if (text.toLowerCase().startsWith("deploy site")) {
                fetch('<?php echo site_url("/wp-json/ytvoiceai/v1/webhook"); ?>', {
                    method: 'POST',
                    headers: {'Content-Type':'application/json'},
                    body: JSON.stringify({"command":"deploy"})
                }).then(()=>alert("🚀 Deploy command sent!"));
            }
            else if (text.toLowerCase().startsWith("update homepage")) {
                let newText = text.substring(15).trim();
                fetch('<?php echo site_url("/wp-json/ytvoiceai/v1/webhook"); ?>', {
                    method: 'POST',
                    headers: {'Content-Type':'application/json'},
                    body: JSON.stringify({"command":"update_homepage", "data": newText})
                }).then(()=>alert("📝 Homepage update sent!"));
            }
            else {
                alert("Unrecognized command: " + text);
            }
        };
        recognition.start();
    }
    window.addEventListener('DOMContentLoaded', function() {
        let btn = document.createElement('button');
        btn.innerText = "🎤 AI Voice Control";
        btn.style.position = "fixed";
        btn.style.bottom = "30px";
        btn.style.right = "30px";
        btn.style.zIndex = 99999;
        btn.style.background = "#111";
        btn.style.color = "#fff";
        btn.style.borderRadius = "100px";
        btn.style.padding = "15px 30px";
        btn.style.fontSize = "1.2em";
        btn.style.border = "none";
        btn.style.boxShadow = "0 2px 16px #0008";
        btn.onclick = startVoiceGPT;
        document.body.appendChild(btn);
    });
    </script>
    <?php
});

// 2. REST API handler for webhook commands (NO AUTH — God Mode, so lock down if you want)
add_action('rest_api_init', function () {
    register_rest_route('ytvoiceai/v1', '/webhook', array(
        'methods' => 'POST',
        'callback' => function ($req) {
            $body = json_decode($req->get_body(), true);
            $cmd = strtolower($body['command'] ?? '');
            $data = $body['data'] ?? '';

            if ($cmd === 'deploy') {
                // Change this path to your deploy script!
                shell_exec('python3 /path/to/auto_deploy.py > /tmp/deploy.log 2>&1 &');
                return ['status'=>'Deployment started'];
            }
            if ($cmd === 'update_homepage' && !empty($data)) {
                $home = get_page_by_title('Home');
                if ($home) {
                    wp_update_post(['ID'=>$home->ID, 'post_content'=>$data]);
                    return ['status'=>'Homepage updated'];
                } else {
                    return ['status'=>'Homepage not found'];
                }
            }
            return ['status'=>'No valid command'];
        },
        'permission_callback' => '__return_true' // 🔥 Remove for open God Mode! Lock down if paranoid
    ));
});
?>
