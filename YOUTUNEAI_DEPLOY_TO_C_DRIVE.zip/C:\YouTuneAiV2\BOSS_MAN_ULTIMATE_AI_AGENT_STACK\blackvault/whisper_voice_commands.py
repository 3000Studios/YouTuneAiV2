# Whisper command hook
print("🎙️ Whisper Command Module: Listening for 'Hey Dude' commands.")