import tkinter as tk
from tkinter import messagebox
import subprocess
import os
def run(cmd): subprocess.Popen(["python", cmd])
root = tk.Tk()
root.title("Genesis Launcher")
tk.Button(root, text="Run Watchdog", command=lambda: run("automation/blackvault_ai_core.py")).pack()
tk.Button(root, text="Run Auto-Funnel", command=lambda: run("automation/auto_funnel.py")).pack()
tk.Button(root, text="Quit", command=root.destroy).pack()
root.mainloop()