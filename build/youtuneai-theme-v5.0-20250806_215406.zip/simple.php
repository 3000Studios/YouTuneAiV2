<?php
echo "<h1 style='color: #00ff00; background: #000; padding: 50px; text-align: center;'>YOUTUNEAI PHP TEST - SERVER WORKING!</h1>";
echo "<p style='color: #00ff00; background: #000; padding: 20px; text-align: center; font-size: 20px;'>If you see this, PHP is functioning on the server.</p>";
?>
