<?php
echo "<h1 style='color: red; font-size: 50px;'>PHP IS WORKING!</h1>";
echo "<p style='color: green; font-size: 24px;'>Server: " . $_SERVER['SERVER_NAME'] . "</p>";
echo "<p style='color: blue; font-size: 20px;'>Time: " . date('Y-m-d H:i:s') . "</p>";
echo "<p style='color: orange; font-size: 20px;'>This proves PHP execution is functional.</p>";
echo "<a href='index.html' style='color: yellow; font-size: 18px;'>Test HTML Page</a>";
?>
