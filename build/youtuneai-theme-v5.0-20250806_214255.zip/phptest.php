<?php
// YouTuneAI Server Test
echo "<!DOCTYPE html>";
echo "<html><head><title>YouTuneAI Server Test</title>";
echo "<style>";
echo "body { background: linear-gradient(135deg, #050510, #1a0a30); color: #ffffff; font-family: Arial; padding: 50px; text-align: center; min-height: 100vh; }";
echo "h1 { font-size: 4rem; color: #00ff88; text-shadow: 0 0 20px rgba(0,255,136,0.8); }";
echo ".status { background: rgba(0,255,136,0.2); padding: 20px; border-radius: 10px; margin: 30px 0; }";
echo "</style></head><body>";
echo "<h1>YOUTUNEAI PHP TEST</h1>";
echo "<div class='status'>";
echo "<p>✅ PHP Version: " . phpversion() . "</p>";
echo "<p>✅ Server Time: " . date('Y-m-d H:i:s') . "</p>";
echo "<p>✅ WordPress: " . (function_exists('wp_head') ? 'LOADED' : 'NOT LOADED') . "</p>";
echo "</div>";
if (function_exists('get_template_directory')) {
    echo "<p>Current Theme Directory: " . get_template_directory() . "</p>";
}
echo "</body></html>";
?>
