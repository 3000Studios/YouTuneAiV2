📦 CodeGPT Gemini 2.5 Flash Auto-Run Config
==========================================

1. Unzip this into the root of your VS Code repo (e.g., YouTuneAiV2/)
2. It will auto-run CodeGPT with Gemini 2.5 Flash
3. The automation task:
   → Unzips wp_plugin_sync_bundle.zip
   → Uploads plugin folders via SFTP
   → Logs everything into plugin_upload_log.md

✅ Just reload your workspace and CodeGPT will handle everything.
