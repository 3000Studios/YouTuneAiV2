@echo off
echo Launching All AI Agents...
python blackvault/agent_launcher.py
pause